#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Date      :  2020-06-16
@Author    :  KylinLu
@Email     :  lusonglin23@foxmail.com
@File      :  diskAlert
@Software  :  PyCharm
"""

import configparser
import datetime, os
import tkinter as tk
import tkinter.messagebox
import win32com.client as win32
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.interval import IntervalTrigger
from remoteServerTools import RemoteServerTools
from csvTools import CsvTools
from logger import Logger


def message_showinfo(msg):
    window = tk.Tk()
    window.withdraw()
    window.update()
    msgBox = tk.messagebox.showinfo(title='磁盘信息', message=msg)
    return msgBox


def outlook(addressee, cc, projectName, body):
    olook = win32.Dispatch("outlook.Application")  # 固定写法
    mail = olook.CreateItem(0)  # 0 == win32.constants.olMailItem
    mail.To = addressee  # 收件人
    mail.CC = cc  # 抄送人
    # mail.Recipients.Add(addressee)
    mail.Subject = f'{projectName}-服务器磁盘报警邮件' + '[' + str(datetime.datetime.now())[0:19] + ']'  # 邮件主题
    # mail.Attachments.Add(mail_path, 1, 1, "myFile")
    # read = open(mail_path, encoding='utf-8')  # 打开需要发送的测试报告附件文件
    # content = read.read()  # 读取测试报告文件中的内容
    # read.close()
    # mail.Body = content  # 将从报告中读取的内容，作为邮件正文中的内容
    mail.Body = body
    mail.Send()  # 发送


def remoteCmd(ip, username, password, port, cmd):
    remoteTools = RemoteServerTools(ip, username, password, port)
    remoteTools.connect()
    res = remoteTools.run_cmd(cmd)
    remoteTools.close()
    return res[1]


def get_res(res_info, threshold, assign_disk=''):
    split_val = []
    list_res_info = res_info.split('\n')

    for i in list_res_info:
        value = i.split()
        if '-' not in value:
            split_val.append(value)
    del(split_val[0])

    ret_msg = ''
    for v in split_val:
        if assign_disk == '':
            used_perc = int(v[4].split('%')[0])
            if used_perc > threshold:
                ret_msg += f"文件系统分区 [{v[0]}] 的磁盘使用率已超过{threshold}%阈值，该磁盘当前的使用率为：{used_perc}%\n"
            else:
                ret_msg += f"文件系统分区 [{v[0]}] 的磁盘使用率未超过{threshold}%阈值，该磁盘当前的使用率为：{used_perc}%\n"
        elif assign_disk != '' and assign_disk == v[0]:
            used_perc = int(v[4].split('%')[0])
            if used_perc > threshold:
                ret_msg += f"指定文件系统分区 [{v[0]}] 的磁盘使用率已超过{threshold}%阈值，该磁盘当前的使用率为：{used_perc}%\n"
            else:
                ret_msg += f"指定文件系统分区 [{v[0]}] 的磁盘使用率未超过{threshold}%阈值，该磁盘当前的使用率为：{used_perc}%\n"
    return ret_msg


def job_function(job, int_kind, int_num, st_date, ed_date):
    try:
        # BlockingScheduler
        sched = BlockingScheduler()
        if st_date == '' and ed_date == '':
            if int_kind == 'seconds':
                trigger = IntervalTrigger(seconds=int(int_num))
                sched.add_job(job, trigger)
                log.logger.debug(f'定时任务策略为：\n每 [{int_num} seconds] 执行一次')
            elif int_kind == 'minutes':
                trigger = IntervalTrigger(minutes=int(int_num))
                sched.add_job(job, trigger)
                log.logger.debug(f'定时任务策略为：\n每 [{int_num} minutes] 执行一次')
            elif int_kind == 'hours':
                trigger = IntervalTrigger(hours=int(int_num))
                sched.add_job(job, trigger)
                log.logger.debug(f'定时任务策略为：\n每 [{int_num} hours] 执行一次')
            elif int_kind == 'days':
                trigger = IntervalTrigger(days=int(int_num))
                sched.add_job(job, trigger)
                log.logger.debug(f'定时任务策略为：\n每 [{int_num} days] 执行一次')
            elif int_kind == 'weeks':
                trigger = IntervalTrigger(weeks=int(int_num))
                sched.add_job(job, trigger)
                log.logger.debug(f'定时任务策略为：\n每 [{int_num} weeks] 执行一次')
            else:
                raise Exception(
                    f"报错信息 : \n定时任务设置的间隔时间类型为：[{int_kind}]，设置错误，请重新设置...")
        elif st_date != '' and ed_date != '':
            if int_kind == 'seconds':
                trigger = IntervalTrigger(seconds=int(int_num), start_date=st_date, end_date=ed_date)
                sched.add_job(job, trigger)
                log.logger.debug(f'定时任务策略为：\n从 [{st_date}] 至 [{ed_date}]，每[{int_num} seconds]执行一次')
            elif int_kind == 'minutes':
                trigger = IntervalTrigger(minutes=int(int_num), start_date=st_date, end_date=ed_date)
                sched.add_job(job, trigger)
                log.logger.debug(f'定时任务策略为：\n从 [{st_date}] 至 [{ed_date}]，每[{int_num} minutes]执行一次')
            elif int_kind == 'hours':
                trigger = IntervalTrigger(hours=int(int_num), start_date=st_date, end_date=ed_date)
                sched.add_job(job, trigger)
                log.logger.debug(f'定时任务策略为：\n从 [{st_date}] 至 [{ed_date}]，每[{int_num} hours]执行一次')
            elif int_kind == 'days':
                trigger = IntervalTrigger(days=int(int_num), start_date=st_date, end_date=ed_date)
                sched.add_job(job, trigger)
                log.logger.debug(f'定时任务策略为：\n从 [{st_date}] 至 [{ed_date}]，每[{int_num} days]执行一次')
            elif int_kind == 'weeks':
                trigger = IntervalTrigger(weeks=int(int_num), start_date=st_date, end_date=ed_date)
                sched.add_job(job, trigger)
                log.logger.debug(f'定时任务策略为：\n从 [{st_date}] 至 [{ed_date}]，每[{int_num} weeks]执行一次')
            else:
                raise Exception(
                    f"报错信息 : \n定时任务设置的间隔时间类型为：[{int_kind}]，设置错误，请重新设置...")
        else:
            raise Exception(
                f"报错信息 : \n定时任务设置的启动时间为：[{st_date}]，停止时间为：[{ed_date}]；设置错误，请重新设置...")
        log.logger.info("服务器磁盘警报定时任务已设置完毕...等待触发定时任务中...")
        sched.start()
    except (KeyboardInterrupt, SystemExit):
        sched.shutdown()


def main():
    """
    df -hP | awk '{print $1,$5}' | column -t    # linux
    df _mp | awk '{print $1,$5}'    # aix
    """
    try:
        # 配置文件位置
        default_path = os.path.dirname(os.path.realpath(__file__))
        configFileName = default_path + '\os_info.csv'

        # 读取远程服务器信息并生成反馈结果
        csvTools = CsvTools(configFileName)
        serverDatas = csvTools.getCsvData()
        result_msg = ''
        for server in serverDatas:
            if server['os_type'] == 'linux' or server['os_type'] == 'Linux':
                server_info = f"Linux服务器（{server['server_kind']}） [{server['ip']}] 的磁盘检查信息如下：\n"
            elif server['os_type'] == 'aix' or server['os_type'] == 'Aix':
                server_info = f"Aix服务器（{server['server_kind']}） [{server['ip']}] 的磁盘检查信息如下：\n"
            server_disk_info = remoteCmd(
                server['ip'], server['username'], server['passwd'], server['port'], cmd='df -mP')
            log.logger.debug(
                f"服务器类型为：[{server['server_kind']}]，服务器IP为：[{server['ip']}]，登录用户为：[{server['username']}]，登录密码为：[{server['passwd']}]，远程执行的命令为：[df -mP]")
            res_info = server_disk_info.decode('utf-8').strip()
            log.logger.debug(f"执行结果如下：\n{res_info}")
            result_info = get_res(res_info, int(conf["基础配置"]["阈值"]), server['filesystem'])
            result_msg = result_msg + server_info + result_info + '\n'

        # 单机版-弹窗警报
        if conf["单机版"]["是否开启"] == '0' or conf["单机版"]["是否开启"] == '否' or conf["单机版"]["是否开启"] == '':
            pass
        elif conf["单机版"]["是否开启"] == '1' or conf["单机版"]["是否开启"] == '是':
            message_showinfo(result_msg)
            log.logger.info("单机版弹窗警报执行完毕...")
            log.logger.debug(f"结果如下：\n{result_msg}")

        # 联机版-邮件警报
        if conf["邮件版"]["是否开启"] == '0' or conf["邮件版"]["是否开启"] == '否' or conf["邮件版"]["是否开启"] == '':
            pass
        elif conf["邮件版"]["是否开启"] == '1' or conf["邮件版"]["是否开启"] == '是':
            if conf["邮件版"]["邮箱类型"] == 'outlook' or conf["邮件版"]["邮箱类型"] == 'Outlook':
                # mail_path = os.path.join(r'D:\Python\test1', 'content', 'test.html')
                outlook(conf["邮件版"]["收件人"], conf["邮件版"]["抄送"], conf["邮件版"]["项目名"], result_msg)
                send_time = '[' + str(datetime.datetime.now())[0:19] + ']'
                log.logger.info(f"服务器磁盘警报邮件已发送...发送时间为：{send_time}")
                log.logger.debug(f"邮件内容如下：\n{result_msg}")
            else:
                log.logger.info(f'当前选择的邮箱类型为：[{conf["邮件版"]["邮箱类型"]}]，暂不支持该类型邮箱，请重新选择...')
    except Exception as e:
        print(f"报错信息：\n{e}")
        log.logger.error(f"报错信息：\n{e}")


if __name__ == '__main__':
    try:
        default_path = os.path.dirname(os.path.realpath(__file__))
        config_path = os.path.join(default_path, "config.ini")
        conf = configparser.ConfigParser()
        conf.read(config_path, encoding='utf-8')

        log = Logger('all.log', level=conf["日志"]["日志级别"])

        if conf["定时任务"]["是否开启"] == '0' or conf["定时任务"]["是否开启"] == '否' or conf["定时任务"]["是否开启"] == '':
            main()
        elif conf["定时任务"]["是否开启"] == '1' or conf["定时任务"]["是否开启"] == '是':
            job_function(
                main, conf["定时任务"]["间隔时间类型"], conf["定时任务"]["间隔时间整型值"],
                conf["定时任务"]["启动时间"], conf["定时任务"]["停止时间"])
    except Exception as e:
        print(f"报错信息：\n{e}")
        log.logger.error(f"报错信息：\n{e}")
    finally:
        os.system("pause")

    # def job_function():
    #     """
    #     date参数：
    #     最基本的一种调度，作业只会执行一次。它的参数如下：
    #     run_date (datetime|str) – the date/time to run the job at
    #     timezone (datetime.tzinfo|str) – time zone for run_date if it doesn’t have one already
    #
    #     cron参数：
    #     year (int|str) – 4-digit year
    #     month (int|str) – month (1-12)
    #     day (int|str) – day of the (1-31)
    #     week (int|str) – ISO week (1-53)
    #     day_of_week (int|str) – number or name of weekday (0-6 or mon,tue,wed,thu,fri,sat,sun)
    #     hour (int|str) – hour (0-23)
    #     minute (int|str) – minute (0-59)
    #     second (int|str) – second (0-59)
    #     start_date (datetime|str) – earliest possible date/time to trigger on (inclusive)
    #     end_date (datetime|str) – latest possible date/time to trigger on (inclusive)
    #     timezone (datetime.tzinfo|str) – time zone to use for the date/time calculations (defaults to scheduler timezone)
    #
    #     interval参数：
    #     weeks (int) – number of weeks to wait
    #     days (int) – number of days to wait
    #     hours (int) – number of hours to wait
    #     minutes (int) – number of minutes to wait
    #     seconds (int) – number of seconds to wait
    #     start_date (datetime|str) – starting point for the interval calculation
    #     end_date (datetime|str) – latest possible date/time to trigger on
    #     timezone (datetime.tzinfo|str) – time zone to use for the date/time calculations
    #     """
    #     print("Hello World")
    #     # BlockingScheduler
    #     sched = BlockingScheduler()
    #     # Schedule job_function to be called every two hours
    #     sched.add_job(job_function, 'interval', hours=2)
    #     # Runs from Monday to Friday at 5:30 (am) until 2014-05-30 00:00:00
    #     sched.add_job(job_function, 'cron', day_of_week='mon-fri', hour=5, minute=30, end_date='2014-05-30')
    #     # The same as before, but starts on 2010-10-10 at 9:30 and stops on 2014-06-15 at 11:00
    #     sched.add_job(job_function, 'interval', hours=2, start_date='2010-10-10 09:30:00',
    #                   end_date='2014-06-15 11:00:00')
    #     sched.start()