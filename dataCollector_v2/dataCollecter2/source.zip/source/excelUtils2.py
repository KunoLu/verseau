#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Date      :  2020-12-01
@Author    :  KylinLu
@Email     :  lusonglin23@foxmail.com
@File      :  excelUtils
@Software  :  PyCharm
"""
import datetime
import xlsxwriter


class ExcelUtils2(object):
    def __init__(self):
        nowTime = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        file_name = 'dataCollecter_' + str(nowTime) + '.xlsx'
        self.workbook = xlsxwriter.Workbook(file_name)

    def write_load_host_data(self, load_host_cpu_keys, load_host_cpu_values, load_host_mem_keys, load_host_mem_values,
                             user):
        load_host_sheet = self.workbook.add_worksheet('load_host')

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            load_host_cpu_keys,
            load_host_cpu_values,
            load_host_mem_keys,
            load_host_mem_values
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        # host cpu
        load_host_sheet.set_column('A:A', 15)
        load_host_sheet.set_column('B:B', 20)
        load_host_sheet.write('A1', "CPU", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        load_host_sheet.write_row('A2', ["用户数"], headerStyle)
        load_host_sheet.write(1, 1, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        load_host_sheet.write_row('A3', ["服务器", "平均CPU使用率（%）"], headerStyle)
        load_host_sheet.write_column('A4', data[0], bold)
        load_host_sheet.write_column('B4', data[1], bold)

        # host mem
        load_host_sheet.set_column('F:F', 15)
        load_host_sheet.set_column('G:G', 20)
        load_host_sheet.write('F1', "MEM", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        load_host_sheet.write_row('F2', ["用户数"], headerStyle)
        load_host_sheet.write(1, 6, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        load_host_sheet.write_row('F3', ["服务器", "平均内存使用率（%）"], headerStyle)
        load_host_sheet.write_column('F4', data[2], bold)
        load_host_sheet.write_column('G4', data[3], bold)

    def write_load_docker_data(self, load_docker_cpu_keys, load_docker_cpu_values, load_docker_mem_keys,
                               load_docker_mem_values, user):
        load_docker_sheet = self.workbook.add_worksheet('load_docker')

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            load_docker_cpu_keys,
            load_docker_cpu_values,
            load_docker_mem_keys,
            load_docker_mem_values
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        # docker cpu
        load_docker_sheet.set_column('A:A', 15)
        load_docker_sheet.set_column('B:B', 20)
        load_docker_sheet.write('A1', "容器CPU", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        load_docker_sheet.write_row('A2', ["用户数"], headerStyle)
        load_docker_sheet.write(1, 1, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        load_docker_sheet.write_row('A3', ["容器", "平均CPU使用率（%）"], headerStyle)
        load_docker_sheet.write_column('A4', data[0], bold)
        load_docker_sheet.write_column('B4', data[1], bold)

        # docker mem
        load_docker_sheet.set_column('F:F', 15)
        load_docker_sheet.set_column('G:G', 20)
        load_docker_sheet.write('F1', "容器MEM", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        load_docker_sheet.write_row('F2', ["用户数"], headerStyle)
        load_docker_sheet.write(1, 6, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        load_docker_sheet.write_row('F3', ["容器", "平均内存使用率（%）"], headerStyle)
        load_docker_sheet.write_column('F4', data[2], bold)
        load_docker_sheet.write_column('G4', data[3], bold)

    def write_load_jmeter_data(self, load_jmeter_rt_keys, load_jmeter_rt_values, load_jmeter_tps_keys,
                               load_jmeter_tps_values, user):
        load_jmeter_sheet = self.workbook.add_worksheet('load_jmeter')

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            load_jmeter_rt_keys,
            load_jmeter_rt_values,
            load_jmeter_tps_keys,
            load_jmeter_tps_values
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        # jmeter rt
        load_jmeter_sheet.set_column('A:A', 15)
        load_jmeter_sheet.set_column('B:B', 20)
        load_jmeter_sheet.write('A1', "RT", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        load_jmeter_sheet.write_row('A2', ["用户数"], headerStyle)
        load_jmeter_sheet.write(1, 1, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        load_jmeter_sheet.write_row('A3', ["交易名称", "平均响应时间（毫秒）"], headerStyle)
        load_jmeter_sheet.write_column('A4', data[0], bold)
        load_jmeter_sheet.write_column('B4', data[1], bold)

        # jmeter tps
        load_jmeter_sheet.set_column('F:F', 15)
        load_jmeter_sheet.set_column('G:G', 20)
        load_jmeter_sheet.write('F1', "TPS", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        load_jmeter_sheet.write_row('F2', ["用户数"], headerStyle)
        load_jmeter_sheet.write(1, 6, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        load_jmeter_sheet.write_row('F3', ["交易名称", "系统处理能力（笔/秒）"], headerStyle)
        load_jmeter_sheet.write_column('F4', data[2], bold)
        load_jmeter_sheet.write_column('G4', data[3], bold)
        total = 0
        for index in data[3]:
            total += float(index)
        row = 'F' + str(len(data[3]) + 4)
        load_jmeter_sheet.write_row(row, ['Total', total],
                                    self.workbook.add_format({'align': 'center', 'border': 1, 'bold': True}))

    def write_cap_host_cpu_data(self, *details):
        global cap_host_sheet
        cap_host_sheet = self.workbook.add_worksheet('cap_host')

        userCount = len(details) - 2

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            *details
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        cap_host_sheet.write('A1', "CPU", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        cap_host_sheet.write_row('A2', ["用户数"], headerStyle)
        cap_host_sheet.write_row('A3', ["服务器"], headerStyle)

        for index in range(userCount):
            cap_host_sheet.write(1, index + 1, details[-1][index],
                                 self.workbook.add_format({'align': 'center', 'border': 1}))
        cap_host_sheet.merge_range(2, 1, 2, userCount, '平均CPU使用率（%）', self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
        }))
        cap_host_sheet.set_column(0, 0, 15)
        for index in range(userCount + 1):
            cap_host_sheet.set_column(3, index + 1, 10)
            cap_host_sheet.write_column(3, index, data[index], bold)

    def write_cap_host_mem_data(self, *details):
        userCount = len(details) - 2

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            *details
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        cap_host_sheet.write(0, userCount + 4, "MEM",
                             self.workbook.add_format({'font_color': 'red', 'bold': True}))

        cap_host_sheet.write_row(1, userCount + 4, ["用户数"], headerStyle)
        cap_host_sheet.write_row(2, userCount + 4, ["服务器"], headerStyle)

        for index in range(userCount):
            cap_host_sheet.write(1, userCount + index + 5, details[-1][index],
                                 self.workbook.add_format({'align': 'center', 'border': 1}))
        cap_host_sheet.merge_range(2, userCount + 5, 2, userCount + 4 + userCount, '平均内存使用率（%）',
                                   self.workbook.add_format({
                                       'bold': True,  # 字体加粗
                                       'border': 1,
                                       'align': 'center',  # 水平对齐方式
                                       'valign': 'vcenter',  # 垂直对齐方式
                                       'fg_color': '#d9d9d9',  # 单元格背景颜色
                                   }))
        cap_host_sheet.set_column(userCount + 4, userCount + 4, 15)
        for index in range(userCount + 1):
            cap_host_sheet.set_column(userCount + index + 5, userCount + index + 5, 10)
            cap_host_sheet.write_column(3, userCount + index + 4, data[index], bold)

    def write_cap_docker_cpu_data(self, *details):
        global cap_docker_sheet
        cap_docker_sheet = self.workbook.add_worksheet('cap_docker')

        userCount = len(details) - 2

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            *details
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        cap_docker_sheet.write('A1', "容器CPU", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        cap_docker_sheet.write_row('A2', ["用户数"], headerStyle)
        cap_docker_sheet.write_row('A3', ["容器"], headerStyle)
        for index in range(userCount):
            cap_docker_sheet.write(1, index + 1, details[-1][index],
                                   self.workbook.add_format({'align': 'center', 'border': 1}))
        cap_docker_sheet.merge_range(2, 1, 2, userCount, '平均CPU使用率（%）', self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
        }))
        cap_docker_sheet.set_column(0, 0, 15)
        for index in range(userCount + 1):
            cap_docker_sheet.set_column(3, index + 1, 10)
            cap_docker_sheet.write_column(3, index, data[index], bold)

    def write_cap_docker_mem_data(self, *details):
        userCount = len(details) - 2

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            *details
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        cap_docker_sheet.write(0, userCount + 4, "容器MEM",
                               self.workbook.add_format({'font_color': 'red', 'bold': True}))
        cap_docker_sheet.write_row(1, userCount + 4, ["用户数"], headerStyle)
        cap_docker_sheet.write_row(2, userCount + 4, ["容器"], headerStyle)
        for index in range(userCount):
            cap_docker_sheet.write(1, userCount + index + 5, details[-1][index],
                                   self.workbook.add_format({'align': 'center', 'border': 1}))
        cap_docker_sheet.merge_range(2, userCount + 5, 2, userCount + 4 + userCount, '平均内存使用率（%）',
                                     self.workbook.add_format({
                                         'bold': True,  # 字体加粗
                                         'border': 1,
                                         'align': 'center',  # 水平对齐方式
                                         'valign': 'vcenter',  # 垂直对齐方式
                                         'fg_color': '#d9d9d9',  # 单元格背景颜色
                                     }))
        cap_docker_sheet.set_column(userCount + 4, userCount + 4, 15)
        for index in range(userCount + 1):
            cap_docker_sheet.set_column(userCount + index + 5, userCount + index + 5, 10)
            cap_docker_sheet.write_column(3, userCount + index + 4, data[index], bold)

    def write_cap_jmeter_rt_data(self, *details):
        global cap_jmeter_sheet
        cap_jmeter_sheet = self.workbook.add_worksheet('cap_jmeter')

        userCount = len(details) - 2

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            *details
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        cap_jmeter_sheet.write('A1', "RT", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        cap_jmeter_sheet.write_row('A2', ["用户数"], headerStyle)
        cap_jmeter_sheet.write_row('A3', ["交易名称"], headerStyle)
        for index in range(userCount):
            cap_jmeter_sheet.write(1, index + 1, details[-1][index],
                                   self.workbook.add_format({'align': 'center', 'border': 1}))
        cap_jmeter_sheet.merge_range(2, 1, 2, userCount, '平均响应时间（毫秒）', self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
        }))
        cap_jmeter_sheet.set_column(0, 0, 15)
        for index in range(userCount + 1):
            cap_jmeter_sheet.set_column(3, index + 1, 10)
            cap_jmeter_sheet.write_column(3, index, data[index], bold)

    def write_cap_jmeter_tps_data(self, *details):
        userCount = len(details) - 2

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            *details
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        cap_jmeter_sheet.write(0, userCount + 4, "TPS",
                               self.workbook.add_format({'font_color': 'red', 'bold': True}))
        cap_jmeter_sheet.write_row(1, userCount + 4, ["用户数"], headerStyle)
        cap_jmeter_sheet.write_row(2, userCount + 4, ["交易名称"], headerStyle)
        for index in range(userCount):
            cap_jmeter_sheet.write(1, userCount + index + 5, details[-1][index],
                                   self.workbook.add_format({'align': 'center', 'border': 1}))
        cap_jmeter_sheet.merge_range(2, userCount + 5, 2, userCount + 4 + userCount, '系统处理能力（笔/秒）',
                                     self.workbook.add_format({
                                         'bold': True,  # 字体加粗
                                         'border': 1,
                                         'align': 'center',  # 水平对齐方式
                                         'valign': 'vcenter',  # 垂直对齐方式
                                         'fg_color': '#d9d9d9',  # 单元格背景颜色
                                     }))
        cap_jmeter_sheet.set_column(userCount + 4, userCount + 4, 15)
        for index in range(userCount + 1):
            cap_jmeter_sheet.set_column(userCount + index + 5, userCount + index + 5, 10)
            cap_jmeter_sheet.write_column(3, userCount + index + 4, data[index], bold)

        totals = []
        for page in data[1:-1]:
            total = 0
            for index in page:
                total += float(index)
            totals.append(total)
        row = len(data[1]) + 3
        cap_jmeter_sheet.write_row(row, userCount + 4, ['Total'] + totals,
                                   self.workbook.add_format({'align': 'center', 'border': 1, 'bold': True}))

    def write_soak_host_data(self, soak_host_cpu_keys, soak_host_cpu_values, soak_host_mem_keys,
                             soak_host_mem_values, user):
        soak_host_sheet = self.workbook.add_worksheet('soak_host')

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            soak_host_cpu_keys,
            soak_host_cpu_values,
            soak_host_mem_keys,
            soak_host_mem_values
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        # soak cpu
        soak_host_sheet.set_column('A:A', 15)
        soak_host_sheet.set_column('B:B', 20)
        soak_host_sheet.write('A1', "CPU", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        soak_host_sheet.write_row('A2', ["用户数"], headerStyle)
        soak_host_sheet.write(1, 1, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        soak_host_sheet.write_row('A3', ["服务器", "平均CPU使用率（%）"], headerStyle)
        soak_host_sheet.write_column('A4', data[0], bold)
        soak_host_sheet.write_column('B4', data[1], bold)

        # soak mem
        soak_host_sheet.set_column('F:F', 15)
        soak_host_sheet.set_column('G:G', 20)
        soak_host_sheet.write('F1', "MEM", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        soak_host_sheet.write_row('F2', ["用户数"], headerStyle)
        soak_host_sheet.write(1, 6, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        soak_host_sheet.write_row('F3', ["服务器", "平均内存使用率（%）"], headerStyle)
        soak_host_sheet.write_column('F4', data[2], bold)
        soak_host_sheet.write_column('G4', data[3], bold)

    def write_soak_docker_data(self, soak_docker_cpu_keys, soak_docker_cpu_values, soak_docker_mem_keys,
                               soak_docker_mem_values, user):
        soak_docker_sheet = self.workbook.add_worksheet('soak_docker')

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            soak_docker_cpu_keys,
            soak_docker_cpu_values,
            soak_docker_mem_keys,
            soak_docker_mem_values
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        # soak docker cpu
        soak_docker_sheet.set_column('A:A', 15)
        soak_docker_sheet.set_column('B:B', 20)
        soak_docker_sheet.write('A1', "容器CPU", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        soak_docker_sheet.write_row('A2', ["用户数"], headerStyle)
        soak_docker_sheet.write(1, 1, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        soak_docker_sheet.write_row('A3', ["容器", "平均CPU使用率（%）"], headerStyle)
        soak_docker_sheet.write_column('A4', data[0], bold)
        soak_docker_sheet.write_column('B4', data[1], bold)

        # soak docker mem
        soak_docker_sheet.set_column('F:F', 15)
        soak_docker_sheet.set_column('G:G', 20)
        soak_docker_sheet.write('F1', "容器MEM", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        soak_docker_sheet.write_row('F2', ["用户数"], headerStyle)
        soak_docker_sheet.write(1, 6, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        soak_docker_sheet.write_row('F3', ["容器", "平均内存使用率（%）"], headerStyle)
        soak_docker_sheet.write_column('F4', data[2], bold)
        soak_docker_sheet.write_column('G4', data[3], bold)

    def write_soak_jmeter_data(self, soak_jmeter_rt_keys, soak_jmeter_rt_values, soak_jmeter_tps_keys,
                               soak_jmeter_tps_values, user):
        soak_jmeter_sheet = self.workbook.add_worksheet('soak_jmeter')

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        data = [
            soak_jmeter_rt_keys,
            soak_jmeter_rt_values,
            soak_jmeter_tps_keys,
            soak_jmeter_tps_values
        ]

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        #soak jmeter rt
        soak_jmeter_sheet.set_column('A:A', 15)
        soak_jmeter_sheet.set_column('B:B', 20)
        soak_jmeter_sheet.write('A1', "RT", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        soak_jmeter_sheet.write_row('A2', ["用户数"], headerStyle)
        soak_jmeter_sheet.write(1, 1, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        soak_jmeter_sheet.write_row('A3', ["交易名称", "平均响应时间（毫秒）"], headerStyle)
        soak_jmeter_sheet.write_column('A4', data[0], bold)
        soak_jmeter_sheet.write_column('B4', data[1], bold)

        # soak jmeter tps
        soak_jmeter_sheet.set_column('F:F', 15)
        soak_jmeter_sheet.set_column('G:G', 20)
        soak_jmeter_sheet.write('F1', "TPS", self.workbook.add_format({'font_color': 'red', 'bold': True}))
        soak_jmeter_sheet.write_row('F2', ["用户数"], headerStyle)
        soak_jmeter_sheet.write(1, 6, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        soak_jmeter_sheet.write_row('F3', ["交易名称", "系统处理能力（笔/秒）"], headerStyle)
        soak_jmeter_sheet.write_column('F4', data[2], bold)
        soak_jmeter_sheet.write_column('G4', data[3], bold)
        total = 0
        for index in data[3]:
            total += float(index)
        row = 'F' + str(len(data[3]) + 4)
        soak_jmeter_sheet.write_row(row, ['Total', total],
                                         self.workbook.add_format({'align': 'center', 'border': 1, 'bold': True}))

    def write_soak_total(self, soak_jmeter_rt_keys, soak_jmeter_rt_values, soak_jmeter_tps_keys,
                         soak_jmeter_tps_values, soak_host_cpu_keys, soak_host_cpu_values, soak_host_mem_keys,
                         soak_host_mem_values, soak_docker_cpu_keys, soak_docker_cpu_values, soak_docker_mem_keys,
                         soak_docker_mem_values, user):
        soak_total_sheet = self.workbook.add_worksheet('soak_total')

        total = 0
        for index in soak_jmeter_tps_values:
            total += float(index)

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        soak_total_sheet.set_column('A:A', 25)
        soak_total_sheet.set_column('B:B', 30)
        soak_total_sheet.write_row('A1', ["用户数"], headerStyle)
        soak_total_sheet.write(0, 1, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        soak_total_sheet.write_row('A2', ["总系统处理能力（笔/秒）"], headerStyle)
        soak_total_sheet.write(1, 1, total, self.workbook.add_format({'align': 'center', 'border': 1}))
        soak_total_sheet.write_row('A3', ["交易名称", "平均响应时间（毫秒）"], headerStyle)
        soak_total_sheet.write_column('A4', soak_jmeter_rt_keys, bold)
        soak_total_sheet.write_column('B4', soak_jmeter_rt_values, bold)
        row_length = len(soak_jmeter_rt_values) + 3
        soak_total_sheet.write_row(row_length, 0, ["交易名称", "各交易系统处理能力（笔/秒）"], headerStyle)
        row_length += 1
        soak_total_sheet.write_column(row_length, 0, soak_jmeter_tps_keys, bold)
        soak_total_sheet.write_column(row_length, 1, soak_jmeter_tps_values, bold)
        row_length += len(soak_jmeter_tps_keys)
        soak_total_sheet.write_row(row_length, 0, ["交易成功率"], headerStyle)
        row_length += 1
        soak_total_sheet.merge_range(row_length, 0, row_length, 1, "系统资源使用率", headerStyle)
        row_length += 1
        soak_total_sheet.write_row(row_length, 0, ["服务器", "CPU平均使用率（%）"], headerStyle)
        row_length += 1
        soak_total_sheet.write_column(row_length, 0, soak_host_cpu_keys, bold)
        soak_total_sheet.write_column(row_length, 1, soak_host_cpu_values, bold)
        row_length += len(soak_host_cpu_keys)
        soak_total_sheet.write_row(row_length, 0, ["服务器", "内存平均使用率（%）"], headerStyle)
        row_length += 1
        soak_total_sheet.write_column(row_length, 0, soak_host_mem_keys, bold)
        soak_total_sheet.write_column(row_length, 1, soak_host_mem_values, bold)
        row_length += len(soak_host_mem_keys)
        soak_total_sheet.write_row(row_length, 0, ["容器", "CPU平均使用率（%）"], headerStyle)
        row_length += 1
        soak_total_sheet.write_column(row_length, 0, soak_docker_cpu_keys, bold)
        soak_total_sheet.write_column(row_length, 1, soak_docker_cpu_values, bold)
        row_length += len(soak_docker_cpu_keys)
        soak_total_sheet.write_row(row_length, 0, ["容器", "内存平均使用率（%）"], headerStyle)
        row_length += 1
        soak_total_sheet.write_column(row_length, 0, soak_docker_mem_keys, bold)
        soak_total_sheet.write_column(row_length, 1, soak_docker_mem_values, bold)

    def write_soak_total_no_docker(self, soak_jmeter_rt_keys, soak_jmeter_rt_values, soak_jmeter_tps_keys,
                         soak_jmeter_tps_values, soak_host_cpu_keys, soak_host_cpu_values, soak_host_mem_keys,
                         soak_host_mem_values, user):
        soak_total_sheet = self.workbook.add_worksheet('soak_total')

        total = 0
        for index in soak_jmeter_tps_values:
            total += float(index)

        bold = self.workbook.add_format({
            # 'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',
            'valign': 'vcenter',
            'fg_color': '#FFFFFF',
            # 'text_wrap': True,  # 是否自动换行
        })

        headerStyle = self.workbook.add_format({
            'bold': True,  # 字体加粗
            'border': 1,
            'align': 'center',  # 水平对齐方式
            'valign': 'vcenter',  # 垂直对齐方式
            'fg_color': '#d9d9d9',  # 单元格背景颜色
            # 'text_wrap': True,  # 是否自动换行
            # 'font_color': 'red'
        })

        soak_total_sheet.set_column('A:A', 25)
        soak_total_sheet.set_column('B:B', 30)
        soak_total_sheet.write_row('A1', ["用户数"], headerStyle)
        soak_total_sheet.write(0, 1, user, self.workbook.add_format({'align': 'center', 'border': 1}))
        soak_total_sheet.write_row('A2', ["总系统处理能力（笔/秒）"], headerStyle)
        soak_total_sheet.write(1, 1, total, self.workbook.add_format({'align': 'center', 'border': 1}))
        soak_total_sheet.write_row('A3', ["交易名称", "平均响应时间（毫秒）"], headerStyle)
        soak_total_sheet.write_column('A4', soak_jmeter_rt_keys, bold)
        soak_total_sheet.write_column('B4', soak_jmeter_rt_values, bold)
        row_length = len(soak_jmeter_rt_values) + 3
        soak_total_sheet.write_row(row_length, 0, ["交易名称", "各交易系统处理能力（笔/秒）"], headerStyle)
        row_length += 1
        soak_total_sheet.write_column(row_length, 0, soak_jmeter_tps_keys, bold)
        soak_total_sheet.write_column(row_length, 1, soak_jmeter_tps_values, bold)
        row_length += len(soak_jmeter_tps_keys)
        soak_total_sheet.write_row(row_length, 0, ["交易成功率"], headerStyle)
        row_length += 1
        soak_total_sheet.merge_range(row_length, 0, row_length, 1, "系统资源使用率", headerStyle)
        row_length += 1
        soak_total_sheet.write_row(row_length, 0, ["服务器", "CPU平均使用率（%）"], headerStyle)
        row_length += 1
        soak_total_sheet.write_column(row_length, 0, soak_host_cpu_keys, bold)
        soak_total_sheet.write_column(row_length, 1, soak_host_cpu_values, bold)
        row_length += len(soak_host_cpu_keys)
        soak_total_sheet.write_row(row_length, 0, ["服务器", "内存平均使用率（%）"], headerStyle)
        row_length += 1
        soak_total_sheet.write_column(row_length, 0, soak_host_mem_keys, bold)
        soak_total_sheet.write_column(row_length, 1, soak_host_mem_values, bold)

    def save(self):
        self.workbook.close()

# if __name__ == '__main__':
#     # load_host分页中，A列服务器对应名称
#     load_host_cpu_keys = ['10.114.28.140', '10.114.28.141', '10.114.28.142', '10.114.28.146']
#
#     # load_host分页中，B列平均CPU使用率值
#     load_host_cpu_values = ['0.36%', '17.79%', '20.19%', '5.34%']
#
#     # load_host分页中，F列服务器对应名称
#     load_host_mem_keys = ['10.114.28.140', '10.114.28.141', '10.114.28.142', '10.114.28.146']
#     # load_host分页中，G列平均内存使用率值
#     load_host_mem_values = ['15.36%', '15.79%', '15.19%', '15.34%']
#     user = '100'
#
#     excelUtils = ExcelUtils()
#     excelUtils.write_load_host_cpu_data(load_host_cpu_keys, load_host_cpu_values, user)
#     excelUtils.write_load_host_mem_data(load_host_mem_keys, load_host_mem_values, user)
#
#     # load_docker分页中，A列容器对应名称
#     load_docker_cpu_keys = ['10.114.28.140_test', '10.114.28.141_test', '10.114.28.142_test', '10.114.28.146_test']
#
#     # load_docker分页中，B列平均CPU使用率值
#     load_docker_cpu_values = ['0.36%', '17.79%', '20.19%', '5.34%']
#
#     # load_docker分页中，F列服务器对应名称
#     load_docker_mem_keys = ['10.114.28.140_test', '10.114.28.141_test', '10.114.28.142_test', '10.114.28.146_test']
#
#     # load_docker分页中，G列平均内存使用率值
#     load_docker_mem_values = ['15.36%', '15.79%', '15.19%', '15.34%']
#
#     excelUtils.write_load_docker_cpu_data(load_docker_cpu_keys, load_docker_cpu_values, user)
#     excelUtils.write_load_docker_mem_data(load_docker_mem_keys, load_docker_mem_values, user)
#
#     # load_jmeter分页中，A列交易名称对应值
#     load_jmeter_rt_keys = ['test1', 'test2', 'test3', 'test4']
#
#     # load_jmeter分页中，B列平均响应时间对应值
#     load_jmeter_rt_values = ['56.777', '54.214', '123.210', '74.100']
#
#     # load_jmeter分页中，F列交易名称对应值  !!!注意：excel中，该列值最下行需添加Total!!!
#     load_jmeter_tps_keys = ['test1', 'test2', 'test3', 'test4']
#
#     # load_jmeter分页中，G列系统处理能力对应值    !!!注意：excel中，该列值最下行需添加以下列表中值得总和（与Total对应），小数点均为3位!!!
#     load_jmeter_tps_values = ['156.777', '154.214', '223.210', '174.100']
#
#     # 写入excel中得方法
#     excelUtils.write_load_jmeter_rt_data(load_jmeter_rt_keys, load_jmeter_rt_values, user)
#     excelUtils.write_load_jmeter_tps_data(load_jmeter_tps_keys, load_jmeter_tps_values, user)
#
#     # cap_host分页中，A列服务器对应名称
#     cap_host_cpu_keys = ['10.114.28.140', '10.114.28.141', '10.114.28.142', '10.114.28.146']
#
#     # cap_host分页中，B列~G列平均CPU使用率值
#     cap_host_cpu_values_01 = ['0.36%', '17.79%', '20.19%', '5.34%']
#     cap_host_cpu_values_02 = ['1.36%', '17.79%', '20.19%', '5.34%']
#     cap_host_cpu_values_03 = ['2.36%', '17.79%', '20.19%', '5.34%']
#     cap_host_cpu_values_04 = ['3.36%', '17.79%', '20.19%', '5.34%']
#     cap_host_cpu_values_05 = ['4.36%', '17.79%', '20.19%', '5.34%']
#     cap_host_cpu_values_06 = ['5.36%', '17.79%', '20.19%', '5.34%']
#     cap_host_cpu_values = [['0.36%', '17.79%', '20.19%', '5.34%'],['1.36%', '17.79%', '20.19%', '5.34%'],['2.36%', '17.79%', '20.19%', '5.34%'],
#                            ['3.36%', '17.79%', '20.19%', '5.34%'],['4.36%', '17.79%', '20.19%', '5.34%'],['5.36%', '17.79%', '20.19%', '5.34%']]
#    # cap_host分页中，K列服务器对应名称
#     cap_host_mem_keys = ['10.114.28.140', '10.114.28.141', '10.114.28.142', '10.114.28.146']
#
#     # cap_host分页中，L列~Q列平均内存使用率值
#     cap_host_mem_values_01 = ['15.36%', '15.79%', '15.19%', '15.34%']
#     cap_host_mem_values_02 = ['16.36%', '15.79%', '15.19%', '15.34%']
#     cap_host_mem_values_03 = ['17.36%', '15.79%', '15.19%', '15.34%']
#     cap_host_mem_values_04 = ['18.36%', '15.79%', '15.19%', '15.34%']
#     cap_host_mem_values_05 = ['19.36%', '15.79%', '15.19%', '15.34%']
#     cap_host_mem_values_06 = ['20.36%', '15.79%', '15.19%', '15.34%']
#
#     uses = [100, 200, 300, 400, 500, 600]
#
#     # 写入excel中得方法
#     # excelUtils.write_cap_host_cpu_data(cap_host_cpu_keys, cap_host_cpu_values_01, cap_host_cpu_values_02,
#     #                                    cap_host_cpu_values_03, cap_host_cpu_values_04, cap_host_cpu_values_05,
#     #                                    cap_host_cpu_values_06, uses)
#     excelUtils.write_cap_host_cpu_data(cap_host_cpu_keys, *cap_host_cpu_values, uses)
#
#     excelUtils.write_cap_host_mem_data(cap_host_mem_keys, cap_host_mem_values_01, cap_host_mem_values_02,
#                                        cap_host_mem_values_03, cap_host_mem_values_04, cap_host_mem_values_05,
#                                        cap_host_mem_values_06, uses)
#
#     # cap_docker分页中，A列服务器对应名称
#     cap_docker_cpu_keys = ['10.114.28.140', '10.114.28.141', '10.114.28.142', '10.114.28.146']
#
#     # cap_docker分页中，B列~G列平均CPU使用率值
#     cap_docker_cpu_values_01 = ['0.36%', '17.79%', '20.19%', '5.34%']
#     cap_docker_cpu_values_02 = ['10.36%', '17.79%', '20.19%', '5.34%']
#     cap_docker_cpu_values_03 = ['20.36%', '17.79%', '20.19%', '5.34%']
#     cap_docker_cpu_values_04 = ['30.36%', '17.79%', '20.19%', '5.34%']
#     cap_docker_cpu_values_05 = ['40.36%', '17.79%', '20.19%', '5.34%']
#     cap_docker_cpu_values_06 = ['50.36%', '17.79%', '20.19%', '5.34%']
#
#     # cap_docker分页中，K列服务器对应名称
#     cap_docker_mem_keys = ['10.114.28.140', '10.114.28.141', '10.114.28.142', '10.114.28.146']
#
#     # cap_docker分页中，L列~Q列平均内存使用率值
#     cap_docker_mem_values_01 = ['15.36%', '15.79%', '15.19%', '15.34%']
#     cap_docker_mem_values_02 = ['25.36%', '15.79%', '15.19%', '15.34%']
#     cap_docker_mem_values_03 = ['35.36%', '15.79%', '15.19%', '15.34%']
#     cap_docker_mem_values_04 = ['45.36%', '15.79%', '15.19%', '15.34%']
#     cap_docker_mem_values_05 = ['55.36%', '15.79%', '15.19%', '15.34%']
#     cap_docker_mem_values_06 = ['65.36%', '15.79%', '15.19%', '15.34%']
#     uses = [100, 200, 300, 400, 500, 600]
#     # 写入excel中得方法
#     excelUtils.write_cap_docker_cpu_data(cap_docker_cpu_keys, cap_docker_cpu_values_01, cap_docker_cpu_values_02,
#                                          cap_docker_cpu_values_03, cap_docker_cpu_values_04, cap_docker_cpu_values_05,
#                                          cap_docker_cpu_values_06, uses)
#     excelUtils.write_cap_docker_mem_data(cap_docker_mem_keys, cap_docker_mem_values_01, cap_docker_mem_values_02,
#                                          cap_docker_mem_values_03, cap_docker_mem_values_04, cap_docker_mem_values_05,
#                                          cap_docker_mem_values_06, uses)
#
#     # cap_jmeter分页中，A列交易名称对应值
#     cap_jmeter_rt_keys = ['test1', 'test2', 'test3', 'test4']
#
#     # cap_jmeter分页中，B列~G列平均响应时间对应值
#     cap_jmeter_rt_values_01 = ['56.777', '54.214', '123.210', '74.100']
#     cap_jmeter_rt_values_02 = ['66.777', '54.214', '123.210', '74.100']
#     cap_jmeter_rt_values_03 = ['76.777', '54.214', '123.210', '74.100']
#     cap_jmeter_rt_values_04 = ['86.777', '54.214', '123.210', '74.100']
#     cap_jmeter_rt_values_05 = ['96.777', '54.214', '123.210', '74.100']
#     cap_jmeter_rt_values_06 = ['106.777', '54.214', '123.210', '74.100']
#
#     # cap_jmeter分页中，K列交易名称对应值  !!!注意：excel中，该列值最下行需添加Total!!!
#     cap_jmeter_tps_keys = ['test1', 'test2', 'test3', 'test4']
#
#     # cap_jmeter分页中，L列~Q列系统处理能力对应值    !!!注意：excel中，该列值最下行需添加以下列表中值得总和（与Total对应），小数点均为3位!!!
#     cap_jmeter_tps_values_01 = ['156.777', '154.214', '223.210', '174.100']
#     cap_jmeter_tps_values_02 = ['166.777', '154.214', '223.210', '174.100']
#     cap_jmeter_tps_values_03 = ['176.777', '154.214', '223.210', '174.100']
#     cap_jmeter_tps_values_04 = ['186.777', '154.214', '223.210', '174.100']
#     cap_jmeter_tps_values_05 = ['196.777', '154.214', '223.210', '174.100']
#     cap_jmeter_tps_values_06 = ['206.777', '154.214', '223.210', '174.100']
#     uses = [100, 200, 300, 400, 500, 600]
#
#     # 写入excel中得方法
#     excelUtils.write_cap_jmeter_rt_data(cap_jmeter_rt_keys, cap_jmeter_rt_values_01, cap_jmeter_rt_values_02,
#                                         cap_jmeter_rt_values_03, cap_jmeter_rt_values_04, cap_jmeter_rt_values_05,
#                                         cap_jmeter_rt_values_06, uses)
#
#     excelUtils.write_cap_jmeter_tps_data(cap_jmeter_tps_keys, cap_jmeter_tps_values_01, cap_jmeter_tps_values_02,
#                                          cap_jmeter_tps_values_03, cap_jmeter_tps_values_04, cap_jmeter_tps_values_05,
#                                          cap_jmeter_tps_values_06, uses)
#
#     # soak_host分页中，A列服务器对应名称
#     soak_host_cpu_keys = ['10.114.28.147', '10.114.28.148', '10.114.28.149', '10.114.28.150']
#
#     # soak_host分页中，B列平均CPU使用率值
#     soak_host_cpu_values = ['10.36%', '27.79%', '30.19%', '45.34%']
#
#     # soak_host分页中，F列服务器对应名称
#     soak_host_mem_keys = ['10.114.28.147', '10.114.28.148', '10.114.28.149', '10.114.28.150']
#     # soak_host分页中，G列平均内存使用率值
#     soak_host_mem_values = ['25.36%', '25.79%', '25.19%', '25.34%']
#     user = '100'
#
#     excelUtils.write_soak_host_cpu_data(soak_host_cpu_keys, soak_host_cpu_values, user)
#     excelUtils.write_soak_host_mem_data(soak_host_mem_keys, soak_host_mem_values, user)
#
#     # soak_docker分页中，A列容器对应名称
#     soak_docker_cpu_keys = ['10.114.28.147_test', '10.114.28.148_test', '10.114.28.149_test', '10.114.28.150_test']
#
#     # soak_docker分页中，B列平均CPU使用率值
#     soak_docker_cpu_values = ['10.36%', '17.79%', '20.19%', '45.34%']
#
#     # soak_docker分页中，F列服务器对应名称
#     soak_docker_mem_keys = ['10.114.28.147_test', '10.114.28.148_test', '10.114.28.149_test', '10.114.28.150_test']
#
#     # soak_docker分页中，G列平均内存使用率值
#     soak_docker_mem_values = ['15.36%', '15.79%', '15.19%', '15.34%']
#
#     excelUtils.write_soak_docker_cpu_data(soak_docker_cpu_keys, soak_docker_cpu_values, user)
#     excelUtils.write_soak_docker_mem_data(soak_docker_mem_keys, soak_docker_mem_values, user)
#
#     # soak_jmeter分页中，A列交易名称对应值
#     soak_jmeter_rt_keys = ['test1', 'test2', 'test3', 'test4']
#
#     # soak_jmeter分页中，B列平均响应时间对应值
#     soak_jmeter_rt_values = ['56.777', '54.214', '123.210', '74.100']
#
#     # soak_jmeter分页中，F列交易名称对应值  !!!注意：excel中，该列值最下行需添加Total!!!
#     soak_jmeter_tps_keys = ['test1', 'test2', 'test3', 'test4']
#
#     # soak_jmeter分页中，G列系统处理能力对应值    !!!注意：excel中，该列值最下行需添加以下列表中值得总和（与Total对应），小数点均为3位!!!
#     soak_jmeter_tps_values = ['156.777', '154.214', '223.210', '174.100']
#
#     # 写入excel中得方法
#     excelUtils.write_soak_jmeter_rt_data(soak_jmeter_rt_keys, soak_jmeter_rt_values, user)
#     excelUtils.write_soak_jmeter_tps_data(soak_jmeter_tps_keys, soak_jmeter_tps_values, user)
#     excelUtils.write_soak_total(soak_jmeter_rt_keys, soak_jmeter_rt_values, soak_jmeter_tps_keys,
#                          soak_jmeter_tps_values, soak_host_cpu_keys, soak_host_cpu_values, soak_host_mem_keys,
#                          soak_host_mem_values, soak_docker_cpu_keys, soak_docker_cpu_values, soak_docker_mem_keys,
#                          soak_docker_mem_values, user)
#     excelUtils.save()
