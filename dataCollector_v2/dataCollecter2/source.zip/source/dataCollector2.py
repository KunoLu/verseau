#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Date      :  2020-12-01
@Author    :  KylinLu
@Email     :  lusonglin23@foxmail.com
@File      :  dataCollector2
@Software  :  PyCharm
"""

import os
import re
import time
import datetime
import configparser
from decimal import *
from logger import Logger
# from excelUtils import ExcelUtils
from excelUtils2 import ExcelUtils2
from defineExc import ResException
from influxdb import InfluxDBClient


def login(ip, port, user, pwd, database):
    login_db = InfluxDBClient(ip, port, user, pwd, database)
    return login_db


def timestamp(st, et):
    turn_st = datetime.datetime.strptime(st, "%Y-%m-%d %H:%M:%S")
    ts_st = int(time.mktime(turn_st.timetuple()))
    turn_et = datetime.datetime.strptime(et, "%Y-%m-%d %H:%M:%S")
    ts_et = int(time.mktime(turn_et.timetuple()))
    log.logger.debug("start timeStamp : {0}s ; end timeStamp : {1}s".format(ts_st, ts_et))
    return ts_st, ts_et


def init_timestamp(init_st):
    turn_st = datetime.datetime.strptime(init_st, "%Y-%m-%d %H:%M:%S")
    ts_init_st = int(time.mktime(turn_st.timetuple()))
    log.logger.debug("init start timeStamp : {0}s ".format(ts_init_st))
    return ts_init_st


def utc_timestamp(ts):
    utc_time = datetime.datetime.utcfromtimestamp(ts)
    utc_ts = utc_time + datetime.timedelta(hours=8)
    log.logger.debug("UTC timeStamp : {0} ".format(utc_ts))
    return utc_ts


def res_path():
    if conf["Default"]["result_path"] == '':
        result_path = [x for x in os.listdir('.') if os.path.isdir(x)]
        if 'res_excel_file' in result_path:
            os.chdir(r'%s\res_excel_file' % default_path)
            res_path = os.getcwd()
            log.logger.info(r"The result excel file dir path is : %s" % res_path)
        else:
            res_path = os.path.join(default_path, 'res_excel_file')
            os.mkdir(res_path)
            log.logger.info(r"The result excel file dir path is : %s" % res_path)
    else:
        os.chdir(conf["Default"]["result_path"])
        result_path = [x for x in os.listdir('.') if os.path.isdir(x)]
        if 'res_excel_file' in result_path:
            os.chdir(r'%s\res_excel_file' % conf["Default"]["result_path"])
            res_path = os.getcwd()
            log.logger.info(r"The result excel file dir path is : %s" % res_path)
        else:
            res_path = os.path.join(conf["Default"]["result_path"], 'res_excel_file')
            os.mkdir(res_path)
            log.logger.info(r"The result excel file dir path is : %s" % res_path)
    return res_path


def get_cap_users():
    cap_init_users = conf["Capacity"]["init_users"]
    eg_interval = conf["Capacity"]["each_group_interval"]
    groups_num = conf["Capacity"]["groups"]
    cap_users = []
    usr_int = 0
    while usr_int < int(groups_num):
        eg_int = int(eg_interval) * usr_int
        usrs = int(cap_init_users) + eg_int
        cap_users.append(usrs)
        usr_int += 1
    log.logger.debug("The cap users list is :\n%s" % cap_users)
    return cap_users


def get_host_cpu_points():
    sql = 'SELECT mean(*) FROM "host_cpu" WHERE time >= {_ts_st}s AND time <= {_ts_et}s GROUP BY "host_ip";'.format(
        _ts_st=time_scope[0], _ts_et=time_scope[1])
    log.logger.info("The host cpu query SQL is :\n%s" % sql)
    resultset = str(conn_db.query(sql))
    log.logger.debug("The host cpu resultSet is :\n%s" % resultset)
    keys = re.findall("'host_ip': '(.*?)'", resultset)
    log.logger.debug("The host cpu resultSet keys length : {0}; The keys list is :\n{1}".format(len(keys), keys))
    points = list(conn_db.query(sql).get_points(measurement="host_cpu"))
    values = []
    for item in points:
        value = str(Decimal(item["mean_used"]).quantize(Decimal('0.00'))) + "%"
        values.append(value)
    log.logger.debug(
        "The host cpu resultSet values length : {0}; The values list is :\n{1}".format(len(values), values))
    return keys, values


def get_host_mem_points():
    sql = 'SELECT mean(*) FROM "host_mem" WHERE time >= {_ts_st}s AND time <= {_ts_et}s GROUP BY "host_ip";'.format(
        _ts_st=time_scope[0], _ts_et=time_scope[1])
    log.logger.info("The host mem query SQL is :\n%s" % sql)
    resultset = str(conn_db.query(sql))
    log.logger.debug("The host mem resultSet is :\n%s" % resultset)
    keys = re.findall("'host_ip': '(.*?)'", resultset)
    log.logger.debug("The host mem resultSet keys length : {0}; The keys list is :\n{1}".format(len(keys), keys))
    points = list(conn_db.query(sql).get_points(measurement="host_mem"))
    values = []
    for item in points:
        value = str(Decimal(item["mean_used"]).quantize(Decimal('0.00'))) + "%"
        values.append(value)
    log.logger.debug(
        "The host mem resultSet values length : {0}; The values list is :\n{1}".format(len(values), values))
    return keys, values


def get_docker_cpu_points():
    sql = 'SELECT mean(*) FROM "docker_cpu" WHERE time >= {_ts_st}s AND' \
          ' time <= {_ts_et}s GROUP BY "host_ip","docker_name","ID";'.format(
        _ts_st=time_scope[0], _ts_et=time_scope[1])
    log.logger.info("The docker cpu query SQL is :\n%s" % sql)
    resultset = str(conn_db.query(sql))
    log.logger.debug("The docker cpu resultSet is :\n%s" % resultset)
    contain_host = re.findall("'host_ip': '(.*?)'", resultset)
    k = re.findall("'docker_name': '(.*?)'", resultset)
    s = "-"
    contain_name = [s + i + s for i in k]
    contain_id = re.findall("'ID': '(.*?)'", resultset)
    if len(contain_name) != len(contain_id):
        log.logger.error(
            "len(contain_name_list) = %s; len(contain_id_list) = %s" % (len(contain_name), len(contain_id)))
        raise ResException(
            "len(contain_name_list) = %s\nlen(contain_id_list) = %s" % (len(contain_name), len(contain_id)))
    keys = []
    for i in range(0, len(contain_id)):
        keys.append(contain_host[i] + contain_name[i] + contain_id[i])
    log.logger.debug("The docker cpu resultSet keys length : {0}; The keys list is :\n{1}".format(len(keys), keys))
    points = list(conn_db.query(sql).get_points(measurement="docker_cpu"))
    values = []
    for item in points:
        value = str(Decimal(item["mean_used"]).quantize(Decimal('0.00'))) + "%"
        values.append(value)
    log.logger.debug(
        "The docker cpu resultSet values length : {0}; The values list is :\n{1}".format(len(values), values))
    return keys, values


def get_docker_mem_points():
    sql = 'SELECT mean(*) FROM "docker_mem" WHERE time >= {_ts_st}s AND' \
          ' time <= {_ts_et}s GROUP BY "host_ip","docker_name","ID";'.format(
        _ts_st=time_scope[0], _ts_et=time_scope[1])
    log.logger.info("The docker mem query SQL is :\n%s" % sql)
    resultset = str(conn_db.query(sql))
    log.logger.debug("The docker mem resultSet is :\n%s" % resultset)
    contain_host = re.findall("'host_ip': '(.*?)'", resultset)
    k = re.findall("'docker_name': '(.*?)'", resultset)
    s = "-"
    contain_name = [s + i + s for i in k]
    contain_id = re.findall("'ID': '(.*?)'", resultset)
    if len(contain_name) != len(contain_id):
        log.logger.error(
            "len(contain_name_list) = %s; len(contain_id_list) = %s" % (len(contain_name), len(contain_id)))
        raise ResException(
            "len(contain_name_list) = %s\nlen(contain_id_list) = %s" % (len(contain_name), len(contain_id)))
    keys = []
    for i in range(0, len(contain_name)):
        keys.append(contain_host[i] + contain_name[i] + contain_id[i])
    log.logger.debug("The docker mem resultSet keys length : {0}; The keys list is :\n{1}".format(len(keys), keys))
    points = list(conn_db.query(sql).get_points(measurement="docker_mem"))
    values = []
    for item in points:
        value = str(Decimal(item["mean_used"]).quantize(Decimal('0.00'))) + "%"
        values.append(value)
    log.logger.debug(
        "The docker mem resultSet values length : {0}; The values list is :\n{1}".format(len(values), values))
    return keys, values


def get_trans_response_time():
    series_sql = '''SHOW series FROM "jmeter" WHERE ("application" = '{_application}')''' \
                 ''' AND ("statut" = 'all') AND ("transaction" != 'all');'''.format(_application=application)
    log.logger.info("The transactions name query RT SQL is :\n%s" % series_sql)
    resultset_series = str(conn_db.query(series_sql))
    log.logger.debug("The series resultSet is :\n%s" % resultset_series)
    keys = re.findall(",transaction=(.*?)'", resultset_series)
    log.logger.debug(
        "The transactions name resultSet keys length : {0}; The keys list is :\n{1}".format(len(keys), keys))
    values = []
    i = 0
    for transaction in keys:
        sql = '''SELECT mean("avg") FROM "jmeter" WHERE ("statut" = 'all') AND''' \
              ''' ("transaction" = '{_transaction}') AND''' \
              ''' time >= {_ts_st}s AND time <= {_ts_et}s GROUP BY "transaction";'''.format(_transaction=transaction,
                                                                                            _ts_st=time_scope[0],
                                                                                            _ts_et=time_scope[1])
        i += 1
        log.logger.info("%d) The trans RT query SQL is :\n%s" % (i, sql))
        points = list(conn_db.query(sql).get_points(measurement="jmeter"))
        value = str(Decimal(points[0]["mean"]).quantize(Decimal('0.000')))
        values.append(value)
    log.logger.debug(
        "The trans RT resultSet values length : {0}; The values list is :\n{1}".format(len(values), values))
    return keys, values


def get_trans_tps():
    series_sql = '''SHOW series FROM "jmeter" WHERE ("application" = '{_application}')''' \
                 ''' AND ("statut" = 'all') AND ("transaction" != 'all');'''.format(_application=application)
    log.logger.info("The transactions name query TPS SQL is :\n%s" % series_sql)
    resultset_series = str(conn_db.query(series_sql))
    log.logger.debug("The series resultSet is :\n%s" % resultset_series)
    keys = re.findall(",transaction=(.*?)'", resultset_series)
    log.logger.debug(
        "The transactions name resultSet keys length : {0}; The keys list is :\n{1}".format(len(keys), keys))
    values = []
    i = 0
    for transaction in keys:
        sql = '''SELECT sum("count") FROM "jmeter" WHERE ("statut" = 'ok') AND''' \
              ''' ("transaction" = '{_transaction}') AND''' \
              ''' time >= {_ts_st}s AND time <= {_ts_et}s GROUP BY "transaction";'''.format(_transaction=transaction,
                                                                                            _ts_st=time_scope[0],
                                                                                            _ts_et=time_scope[1])
        i += 1
        log.logger.info("%d) The trans TPS query SQL is :\n%s" % (i, sql))
        points = list(conn_db.query(sql).get_points(measurement="jmeter"))
        total_value = Decimal(points[0]["sum"])
        trans_value = total_value / (Decimal(time_scope[1]) - Decimal(time_scope[0]) + 1)
        value = str(Decimal(trans_value).quantize(Decimal('0.000')))
        values.append(value)
    log.logger.debug(
        "The trans TPS resultSet values length : {0}; The values list is :\n{1}".format(len(values), values))
    return keys, values


if __name__ == '__main__':
    global eu2
    try:
        default_path = os.path.dirname(os.path.realpath(__file__))
        config_path = os.path.join(default_path, "config.ini")
        conf = configparser.ConfigParser()
        conf.read(config_path)

        log = Logger('all.log', level=conf["Log"]["log_level"])

        resPath = res_path()
        os.chdir(resPath)

        # excelUtils = ExcelUtils()
        eu2 = ExcelUtils2()

        load_users = conf["Load"]["load_users"]
        cap_users = get_cap_users()
        soak_users = conf["Soak"]["soak_users"]

        # host
        if conf["Default"]["host"] == '' or int(conf["Default"]["host"]) == 0:
            pass
        elif int(conf["Default"]["host"]) == 1:
            ru_db_ip = conf["resource_utilization"]["influxdb_ip"]
            ru_db_port = conf["resource_utilization"]["influxdb_port"]
            ru_db_user = conf["resource_utilization"]["influxdb_user"]
            ru_db_pwd = conf["resource_utilization"]["influxdb_pwd"]
            ru_db_name = conf["resource_utilization"]["influxdb_database"]

            # load
            if conf["Load"]["whether_load"] == '' or int(conf["Load"]["whether_load"]) == 0:
                pass
            elif int(conf["Load"]["whether_load"]) == 1:
                ru_start_time = conf["Load"]["start_time"]
                ru_end_time = conf["Load"]["end_time"]
                conn_db = login(ru_db_ip, ru_db_port, ru_db_user, ru_db_pwd, ru_db_name)
                time_scope = timestamp(ru_start_time, ru_end_time)

                # host_cpu_mean
                res_host_cpu = get_host_cpu_points()
                log.logger.debug(res_host_cpu[0])
                log.logger.debug(res_host_cpu[1])
                if len(res_host_cpu[1]) == 0:
                    log.logger.error("No host cpu data collected!")
                    raise ResException("No host cpu data collected!")

                # host_mem_mean
                res_host_mem = get_host_mem_points()
                log.logger.debug(res_host_mem[0])
                log.logger.debug(res_host_mem[1])
                if len(res_host_mem[1]) == 0:
                    log.logger.error("No host mem data collected!")
                    raise ResException("No host mem data collected!")

                # excelUtils.write_load_host_cpu_data(res_host_cpu[0], res_host_cpu[1], load_users)
                # excelUtils.write_load_host_mem_data(res_host_mem[0], res_host_mem[1], load_users)
                eu2.write_load_host_data(res_host_cpu[0], res_host_cpu[1], res_host_mem[0], res_host_mem[1], load_users)
            else:
                log.logger.error(
                    "Configure error! Pls modify the config.ini! The whether_load option just input : 0 or 1 !")
                raise ResException(
                    "Configure error! Pls modify the config.ini!\nThe whether_load option just input : 0 or 1 !")

            # capacity
            if conf["Capacity"]["whether_cap"] == '' or int(conf["Capacity"]["whether_cap"]) == 0:
                pass
            elif int(conf["Capacity"]["whether_cap"]) == 1:
                ru_start_time = []
                ru_end_time = []
                conn_db = login(ru_db_ip, ru_db_port, ru_db_user, ru_db_pwd, ru_db_name)
                init_start_time = conf["Capacity"]["start_time"]
                eg_st = init_timestamp(init_start_time) + int(conf["Capacity"]["discard_delay_sec"])
                ru_start_time.append(str(utc_timestamp(eg_st)))
                eg_et = eg_st + int(conf["Capacity"]["each_group_sec"])
                ru_end_time.append(str(utc_timestamp(eg_et)))

                i = 1
                while i < int(conf["Capacity"]["groups"]):
                    eg_st = eg_et + int(conf["Capacity"]["discard_delay_sec"]) * 2
                    ru_start_time.append(str(utc_timestamp(eg_st)))
                    eg_et = eg_st + int(conf["Capacity"]["each_group_sec"])
                    ru_end_time.append(str(utc_timestamp(eg_et)))
                    i += 1
                log.logger.debug("cap start time list :\n%s" % ru_start_time)
                log.logger.debug("cap end time list :\n%s" % ru_end_time)

                if len(ru_start_time) == len(ru_end_time):
                    cap_host_cpu_keys = []
                    cap_host_cpu_values = []
                    cap_host_mem_keys = []
                    cap_host_mem_values = []
                    for i in range(0, len(ru_start_time)):
                        time_scope = timestamp(ru_start_time[i], ru_end_time[i])
                        log.logger.debug("each group time scope :\n%s" % str(time_scope))

                        # host_cpu_mean
                        res_host_cpu = get_host_cpu_points()
                        log.logger.debug(res_host_cpu[0])
                        log.logger.debug(res_host_cpu[1])
                        if len(res_host_cpu[1]) == 0:
                            log.logger.error("No host cpu data collected!")
                            raise ResException("No host cpu data collected!")
                        cap_host_cpu_keys.append(res_host_cpu[0])
                        cap_host_cpu_values.append(res_host_cpu[1])

                        # host_mem_mean
                        res_host_mem = get_host_mem_points()
                        log.logger.debug(res_host_mem[0])
                        log.logger.debug(res_host_mem[1])
                        if len(res_host_mem[1]) == 0:
                            log.logger.error("No host mem data collected!")
                            raise ResException("No host mem data collected!")
                        cap_host_mem_keys.append(res_host_mem[0])
                        cap_host_mem_values.append(res_host_mem[1])

                    log.logger.debug("cap host cpu keys list :\n%s" % cap_host_cpu_keys[0])
                    log.logger.debug("cap host cpu values list :\n%s" % cap_host_cpu_values)
                    log.logger.debug("cap host mem keys list :\n%s" % cap_host_mem_keys[0])
                    log.logger.debug("cap host mem values list :\n%s" % cap_host_mem_values)

                    # excelUtils.write_cap_host_cpu_data(cap_host_cpu_keys[0], *cap_host_cpu_values, cap_users)
                    # excelUtils.write_cap_host_mem_data(cap_host_mem_keys[0], *cap_host_mem_values, cap_users)
                    eu2.write_cap_host_cpu_data(cap_host_cpu_keys[0], *cap_host_cpu_values, cap_users)
                    eu2.write_cap_host_mem_data(cap_host_mem_keys[0], *cap_host_mem_values, cap_users)
                else:
                    log.logger.error(
                        "Time scope cut out error! Cap start time list != cap end time list")
                    raise ResException(
                        "Time scope cut out error! Cap start time list != cap end time list")
            else:
                log.logger.error(
                    "Configure error! Pls modify the config.ini! The whether_cap option just input : 0 or 1 !")
                raise ResException(
                    "Configure e0rror! Pls modify the config.ini!\nThe whether_cap option just input : 0 or 1 !")

            # soak
            if conf["Soak"]["whether_soak"] == '' or int(conf["Soak"]["whether_soak"]) == 0:
                pass
            elif int(conf["Soak"]["whether_soak"]) == 1:
                ru_start_time = conf["Soak"]["start_time"]
                ru_end_time = conf["Soak"]["end_time"]
                conn_db = login(ru_db_ip, ru_db_port, ru_db_user, ru_db_pwd, ru_db_name)
                time_scope = timestamp(ru_start_time, ru_end_time)

                # host_cpu_mean
                res_host_cpu = get_host_cpu_points()
                log.logger.debug(res_host_cpu[0])
                log.logger.debug(res_host_cpu[1])
                if len(res_host_cpu[1]) == 0:
                    log.logger.error("No host cpu data collected!")
                    raise ResException("No host cpu data collected!")

                # host_mem_mean
                res_host_mem = get_host_mem_points()
                log.logger.debug(res_host_mem[0])
                log.logger.debug(res_host_mem[1])
                if len(res_host_mem[1]) == 0:
                    log.logger.error("No host mem data collected!")
                    raise ResException("No host mem data collected!")

                # excelUtils.write_soak_host_cpu_data(res_host_cpu[0], res_host_cpu[1], soak_users)
                # excelUtils.write_soak_host_mem_data(res_host_mem[0], res_host_mem[1], soak_users)
                eu2.write_soak_host_data(res_host_cpu[0], res_host_cpu[1], res_host_mem[0], res_host_mem[1], soak_users)
            else:
                log.logger.error(
                    "Configure error! Pls modify the config.ini! The whether_soak option just input : 0 or 1 !")
                raise ResException(
                    "Configure error! Pls modify the config.ini!\nThe whether_soak option just input : 0 or 1 !")
        else:
            log.logger.error("Configure error! Pls modify the config.ini! The host option just input : 0 or 1 !")
            raise ResException("Configure error! Pls modify the config.ini!\nThe host option just input : 0 or 1 !")

        # docker
        if conf["Default"]["docker"] == '' or int(conf["Default"]["docker"]) == 0:
            pass
        elif int(conf["Default"]["docker"]) == 1:
            ru_db_ip = conf["resource_utilization"]["influxdb_ip"]
            ru_db_port = conf["resource_utilization"]["influxdb_port"]
            ru_db_user = conf["resource_utilization"]["influxdb_user"]
            ru_db_pwd = conf["resource_utilization"]["influxdb_pwd"]
            ru_db_name = conf["resource_utilization"]["influxdb_database"]

            # load
            if conf["Load"]["whether_load"] == '' or int(conf["Load"]["whether_load"]) == 0:
                pass
            elif int(conf["Load"]["whether_load"]) == 1:
                ru_start_time = conf["Load"]["start_time"]
                ru_end_time = conf["Load"]["end_time"]
                conn_db = login(ru_db_ip, ru_db_port, ru_db_user, ru_db_pwd, ru_db_name)
                time_scope = timestamp(ru_start_time, ru_end_time)

                # docker_cpu_mean
                res_docker_cpu = get_docker_cpu_points()
                log.logger.debug(res_docker_cpu[0])
                log.logger.debug(res_docker_cpu[1])
                if len(res_docker_cpu[1]) == 0:
                    log.logger.error("No docker cpu data collected!")
                    raise ResException("No docker cpu data collected!")

                # docker_mem_mean
                res_docker_mem = get_docker_mem_points()
                log.logger.debug(res_docker_mem[0])
                log.logger.debug(res_docker_mem[1])
                if len(res_docker_mem[1]) == 0:
                    log.logger.error("No docker mem data collected!")
                    raise ResException("No docker mem data collected!")

                # excelUtils.write_load_docker_cpu_data(res_docker_cpu[0], res_docker_cpu[1], load_users)
                # excelUtils.write_load_docker_mem_data(res_docker_mem[0], res_docker_mem[1], load_users)
                eu2.write_load_docker_data(res_docker_cpu[0], res_docker_cpu[1], res_docker_mem[0], res_docker_mem[1],
                                           load_users)
            else:
                log.logger.error(
                    "Configure error! Pls modify the config.ini! The whether_load option just input : 0 or 1 !")
                raise ResException(
                    "Configure error! Pls modify the config.ini!\nThe whether_load option just input : 0 or 1 !")

            # capacity
            if conf["Capacity"]["whether_cap"] == '' or int(conf["Capacity"]["whether_cap"]) == 0:
                pass
            elif int(conf["Capacity"]["whether_cap"]) == 1:
                ru_start_time = []
                ru_end_time = []
                conn_db = login(ru_db_ip, ru_db_port, ru_db_user, ru_db_pwd, ru_db_name)
                init_start_time = conf["Capacity"]["start_time"]
                eg_st = init_timestamp(init_start_time) + int(conf["Capacity"]["discard_delay_sec"])
                ru_start_time.append(str(utc_timestamp(eg_st)))
                eg_et = eg_st + int(conf["Capacity"]["each_group_sec"])
                ru_end_time.append(str(utc_timestamp(eg_et)))

                i = 1
                while i < int(conf["Capacity"]["groups"]):
                    eg_st = eg_et + int(conf["Capacity"]["discard_delay_sec"]) * 2
                    ru_start_time.append(str(utc_timestamp(eg_st)))
                    eg_et = eg_st + int(conf["Capacity"]["each_group_sec"])
                    ru_end_time.append(str(utc_timestamp(eg_et)))
                    i += 1
                log.logger.debug("cap start time list :\n%s" % ru_start_time)
                log.logger.debug("cap end time list :\n%s" % ru_end_time)

                if len(ru_start_time) == len(ru_end_time):
                    cap_docker_cpu_keys = []
                    cap_docker_cpu_values = []
                    cap_docker_mem_keys = []
                    cap_docker_mem_values = []
                    for i in range(0, len(ru_start_time)):
                        time_scope = timestamp(ru_start_time[i], ru_end_time[i])
                        log.logger.debug("each group time scope :\n%s" % str(time_scope))

                        # docker_cpu_mean
                        res_docker_cpu = get_docker_cpu_points()
                        log.logger.debug(res_docker_cpu[0])
                        log.logger.debug(res_docker_cpu[1])
                        if len(res_docker_cpu[1]) == 0:
                            log.logger.error("No docker cpu data collected!")
                            raise ResException("No docker cpu data collected!")
                        cap_docker_cpu_keys.append(res_docker_cpu[0])
                        cap_docker_cpu_values.append(res_docker_cpu[1])

                        # docker_mem_mean
                        res_docker_mem = get_docker_mem_points()
                        log.logger.debug(res_docker_mem[0])
                        log.logger.debug(res_docker_mem[1])
                        if len(res_docker_mem[1]) == 0:
                            log.logger.error("No docker mem data collected!")
                            raise ResException("No docker mem data collected!")
                        cap_docker_mem_keys.append(res_docker_mem[0])
                        cap_docker_mem_values.append(res_docker_mem[1])

                    log.logger.debug("cap docker cpu keys list :\n%s" % cap_docker_cpu_keys[0])
                    log.logger.debug("cap docker cpu values list :\n%s" % cap_docker_cpu_values)
                    log.logger.debug("cap docker mem keys list :\n%s" % cap_docker_mem_keys[0])
                    log.logger.debug("cap docker mem values list :\n%s" % cap_docker_mem_values)

                    # excelUtils.write_cap_docker_cpu_data(cap_docker_cpu_keys[0], *cap_docker_cpu_values, cap_users)
                    # excelUtils.write_cap_docker_mem_data(cap_docker_mem_keys[0], *cap_docker_mem_values, cap_users)
                    eu2.write_cap_docker_cpu_data(cap_docker_cpu_keys[0], *cap_docker_cpu_values, cap_users)
                    eu2.write_cap_docker_mem_data(cap_docker_mem_keys[0], *cap_docker_mem_values, cap_users)
                else:
                    log.logger.error(
                        "Time scope cut out error! Cap start time list != cap end time list")
                    raise ResException(
                        "Time scope cut out error! Cap start time list != cap end time list")
            else:
                log.logger.error(
                    "Configure error! Pls modify the config.ini! The whether_cap option just input : 0 or 1 !")
                raise ResException(
                    "Configure error! Pls modify the config.ini!\nThe whether_cap option just input : 0 or 1 !")

            # soak
            if conf["Soak"]["whether_soak"] == '' or int(conf["Soak"]["whether_soak"]) == 0:
                pass
            elif int(conf["Soak"]["whether_soak"]) == 1:
                ru_start_time = conf["Soak"]["start_time"]
                ru_end_time = conf["Soak"]["end_time"]
                conn_db = login(ru_db_ip, ru_db_port, ru_db_user, ru_db_pwd, ru_db_name)
                time_scope = timestamp(ru_start_time, ru_end_time)

                # docker_cpu_mean
                res_docker_cpu = get_docker_cpu_points()
                log.logger.debug(res_docker_cpu[0])
                log.logger.debug(res_docker_cpu[1])
                if len(res_docker_cpu[1]) == 0:
                    log.logger.error("No docker cpu data collected!")
                    raise ResException("No docker cpu data collected!")

                res_docker_mem = get_docker_mem_points()
                log.logger.debug(res_docker_mem[0])
                log.logger.debug(res_docker_mem[1])
                if len(res_docker_mem[1]) == 0:
                    log.logger.error("No docker mem data collected!")
                    raise ResException("No docker mem data collected!")

                # excelUtils.write_soak_docker_cpu_data(res_docker_cpu[0], res_docker_cpu[1], soak_users)
                # excelUtils.write_soak_docker_mem_data(res_docker_mem[0], res_docker_mem[1], soak_users)
                eu2.write_soak_docker_data(res_docker_cpu[0], res_docker_cpu[1], res_docker_mem[0], res_docker_mem[1],
                                           soak_users)
            else:
                log.logger.error(
                    "Configure error! Pls modify the config.ini! The whether_soak option just input : 0 or 1 !")
                raise ResException(
                    "Configure error! Pls modify the config.ini!\nThe whether_soak option just input : 0 or 1 !")
        else:
            log.logger.error("Configure error! Pls modify the config.ini! The docker option just input : 0 or 1 !")
            raise ResException("Configure error! Pls modify the config.ini!\nThe docker option just input : 0 or 1 !")

        # jmeter
        if conf["Default"]["jmeter"] == '' or int(conf["Default"]["jmeter"]) == 0:
            pass
        elif int(conf["Default"]["jmeter"]) == 1:
            jme_db_ip = conf["JMeter"]["influxdb_ip"]
            jme_db_port = conf["JMeter"]["influxdb_port"]
            jme_db_user = conf["JMeter"]["influxdb_user"]
            jme_db_pwd = conf["JMeter"]["influxdb_pwd"]
            jme_db_name = conf["JMeter"]["influxdb_database"]
            application = conf["JMeter"]["application"]

            # load
            if conf["Load"]["whether_load"] == '' or int(conf["Load"]["whether_load"]) == 0:
                pass
            elif int(conf["Load"]["whether_load"]) == 1:
                jme_start_time = conf["Load"]["start_time"]
                jme_end_time = conf["Load"]["end_time"]
                conn_db = login(jme_db_ip, jme_db_port, jme_db_user, jme_db_pwd, jme_db_name)
                time_scope = timestamp(jme_start_time, jme_end_time)

                # transactions_avg_response_time
                trans_rt = get_trans_response_time()
                log.logger.debug(trans_rt[0])
                log.logger.debug(trans_rt[1])
                if len(trans_rt[1]) == 0:
                    log.logger.error("No trans response time data collected! Pls check your database or application!")
                    raise ResException(
                        "No trans response time data collected!\nPls check your database or application!")

                # transactions_avg_tps
                trans_tps = get_trans_tps()
                log.logger.debug(trans_tps[0])
                log.logger.debug(trans_tps[1])
                if len(trans_tps[1]) == 0:
                    log.logger.error("No trans tps data collected! Pls check your database or application!")
                    raise ResException("No trans tps data collected!\nPls check your database or application!")

                # excelUtils.write_load_jmeter_rt_data(trans_rt[0], trans_rt[1], load_users)
                # excelUtils.write_load_jmeter_tps_data(trans_tps[0], trans_tps[1], load_users)
                eu2.write_load_jmeter_data(trans_rt[0], trans_rt[1], trans_tps[0], trans_tps[1], load_users)
            else:
                log.logger.error(
                    "Configure error! Pls modify the config.ini! The whether_load option just input : 0 or 1 !")
                raise ResException(
                    "Configure error! Pls modify the config.ini!\nThe whether_load option just input : 0 or 1 !")

            # capacity
            if conf["Capacity"]["whether_cap"] == '' or int(conf["Capacity"]["whether_cap"]) == 0:
                pass
            elif int(conf["Capacity"]["whether_cap"]) == 1:
                ru_start_time = []
                ru_end_time = []
                conn_db = login(jme_db_ip, jme_db_port, jme_db_user, jme_db_pwd, jme_db_name)
                init_start_time = conf["Capacity"]["start_time"]
                eg_st = init_timestamp(init_start_time) + int(conf["Capacity"]["discard_delay_sec"])
                ru_start_time.append(str(utc_timestamp(eg_st)))
                eg_et = eg_st + int(conf["Capacity"]["each_group_sec"])
                ru_end_time.append(str(utc_timestamp(eg_et)))

                i = 1
                while i < int(conf["Capacity"]["groups"]):
                    eg_st = eg_et + int(conf["Capacity"]["discard_delay_sec"]) * 2
                    ru_start_time.append(str(utc_timestamp(eg_st)))
                    eg_et = eg_st + int(conf["Capacity"]["each_group_sec"])
                    ru_end_time.append(str(utc_timestamp(eg_et)))
                    i += 1
                log.logger.debug("cap start time list :\n%s" % ru_start_time)
                log.logger.debug("cap end time list :\n%s" % ru_end_time)

                if len(ru_start_time) == len(ru_end_time):
                    cap_jmeter_rt_keys = []
                    cap_jmeter_rt_values = []
                    cap_jmeter_tps_keys = []
                    cap_jmeter_tps_values = []
                    for i in range(0, len(ru_start_time)):
                        time_scope = timestamp(ru_start_time[i], ru_end_time[i])
                        log.logger.debug("each group time scope :\n%s" % str(time_scope))

                        # transactions_avg_response_time
                        trans_rt = get_trans_response_time()
                        log.logger.debug(trans_rt[0])
                        log.logger.debug(trans_rt[1])
                        if len(trans_rt[1]) == 0:
                            log.logger.error(
                                "No trans response time data collected! Pls check your database or application!")
                            raise ResException(
                                "No trans response time data collected!\nPls check your database or application!")
                        cap_jmeter_rt_keys.append(trans_rt[0])
                        cap_jmeter_rt_values.append(trans_rt[1])

                        # transactions_avg_tps
                        trans_tps = get_trans_tps()
                        log.logger.debug(trans_tps[0])
                        log.logger.debug(trans_tps[1])
                        if len(trans_tps[1]) == 0:
                            log.logger.error("No trans tps data collected! Pls check your database or application!")
                            raise ResException("No trans tps data collected!\nPls check your database or application!")
                        cap_jmeter_tps_keys.append(trans_tps[0])
                        cap_jmeter_tps_values.append(trans_tps[1])

                    log.logger.debug("cap jmeter rt keys list :\n%s" % cap_jmeter_rt_keys)
                    log.logger.debug("cap jmeter rt values list :\n%s" % cap_jmeter_rt_values)
                    log.logger.debug("cap jmeter tps keys list :\n%s" % cap_jmeter_tps_keys)
                    log.logger.debug("cap jmeter tps values list :\n%s" % cap_jmeter_tps_values)

                    # excelUtils.write_cap_jmeter_rt_data(cap_jmeter_rt_keys[0], *cap_jmeter_rt_values, cap_users)
                    # excelUtils.write_cap_jmeter_tps_data(cap_jmeter_tps_keys[0], *cap_jmeter_tps_values, cap_users)
                    eu2.write_cap_jmeter_rt_data(cap_jmeter_rt_keys[0], *cap_jmeter_rt_values, cap_users)
                    eu2.write_cap_jmeter_tps_data(cap_jmeter_tps_keys[0], *cap_jmeter_tps_values, cap_users)
                else:
                    log.logger.error(
                        "Configure error! Pls modify the config.ini! The whether_cap option just input : 0 or 1 !")
                    raise ResException(
                        "Configure error! Pls modify the config.ini!\nThe whether_cap option just input : 0 or 1 !")
            else:
                log.logger.error(
                    "Configure error! Pls modify the config.ini! The whether_cap option just input : 0 or 1 !")
                raise ResException(
                    "Configure error! Pls modify the config.ini!\nThe whether_cap option just input : 0 or 1 !")

            # soak
            if conf["Soak"]["whether_soak"] == '' or int(conf["Soak"]["whether_soak"]) == 0:
                pass
            elif int(conf["Soak"]["whether_soak"]) == 1:
                jme_start_time = conf["Soak"]["start_time"]
                jme_end_time = conf["Soak"]["end_time"]
                conn_db = login(jme_db_ip, jme_db_port, jme_db_user, jme_db_pwd, jme_db_name)
                time_scope = timestamp(jme_start_time, jme_end_time)

                # transactions_avg_response_time
                trans_rt = get_trans_response_time()
                log.logger.debug(trans_rt[0])
                log.logger.debug(trans_rt[1])
                if len(trans_rt[1]) == 0:
                    log.logger.error(
                        "No trans response time data collected! Pls check your database or application!")
                    raise ResException(
                        "No trans response time data collected!\nPls check your database or application!")

                # transactions_avg_tps
                trans_tps = get_trans_tps()
                log.logger.debug(trans_tps[0])
                log.logger.debug(trans_tps[1])
                if len(trans_tps[1]) == 0:
                    log.logger.error("No trans tps data collected! Pls check your database or application!")
                    raise ResException("No trans tps data collected!\nPls check your database or application!")

                # excelUtils.write_soak_jmeter_rt_data(trans_rt[0], trans_rt[1], soak_users)
                # excelUtils.write_soak_jmeter_tps_data(trans_tps[0], trans_tps[1], soak_users)
                # excelUtils.write_soak_total(trans_rt[0], trans_rt[1], trans_tps[0],
                #                             trans_tps[1], res_host_cpu[0], res_host_cpu[1],
                #                             res_host_mem[0], res_host_mem[1], res_docker_cpu[0],
                #                             res_docker_cpu[1], res_docker_mem[0], res_docker_mem[1], soak_users)
                eu2.write_soak_jmeter_data(trans_rt[0], trans_rt[1], trans_tps[0], trans_tps[1], soak_users)
                if conf["Soak"]["have_docker"] == '' or int(conf["Soak"]["have_docker"]) == 0:
                    eu2.write_soak_total_no_docker(trans_rt[0], trans_rt[1], trans_tps[0],
                                                   trans_tps[1], res_host_cpu[0], res_host_cpu[1],
                                                   res_host_mem[0], res_host_mem[1], soak_users)
                elif int(conf["Soak"]["have_docker"]) == 1:
                    eu2.write_soak_total(trans_rt[0], trans_rt[1], trans_tps[0],
                                         trans_tps[1], res_host_cpu[0], res_host_cpu[1],
                                         res_host_mem[0], res_host_mem[1], res_docker_cpu[0],
                                         res_docker_cpu[1], res_docker_mem[0], res_docker_mem[1], soak_users)
            else:
                log.logger.error(
                    "Configure error! Pls modify the config.ini! The whether_soak option just input : 0 or 1 !")
                raise ResException(
                    "Configure error! Pls modify the config.ini!\nThe whether_soak option just input : 0 or 1 !")
        else:
            log.logger.error("Configure error! Pls modify the config.ini! The jmeter option just input : 0 or 1 !")
            raise ResException("Configure error! Pls modify the config.ini!\nThe jmeter option just input : 0 or 1 !")
    except ResException as ex:
        print(ex)
    finally:
        eu2.save()
        os.system("pause")
