#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Date      :  2020-05-07
@Author    :  KylinLu
@Email     :  lusonglin23@foxmail.com
@File      :  defineExc
@Software  :  PyCharm
"""


class ResException(Exception):

    def __init__(self, ErrorInfo):
        super().__init__(self)
        self.errorinfo = ErrorInfo

    def __str__(self):
        return self.errorinfo