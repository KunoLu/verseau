#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@Date      :  2020-06-20
@Author    :  KylinLu
@Email     :  lusonglin23@foxmail.com
@File      :  dnJMeter
@Software  :  PyCharm
"""
import os
import csv
import time
import paramiko
# import subprocess
import configparser
from defineExc import ResException
from paramiko.ssh_exception import SSHException


def show_mode():
    show = '''(1) local_no_report : 本地控制机发压，不生成测试报告；
(2) remote_assign_no_report : 指定远程压力机发压，不生成测试报告；
(3) remote_all_no_report : 所有远程压力机发压，不生成测试报告；
(4) local_get_report : 本地控制机发压，生成测试报告；
(5) remote_assign_get_report : 指定远程压力机发压，生成测试报告；
(6) remote_all_get_report : 所有远程压力机发压，生成测试报告；
Tips : 
1) 如选择了不生成测试报告的方式发压，后续如需获取对应结果文件的测试报告，则在控制台输入如下命令：
jmeter -g [name.jtl/name.csv] -o [destDir]
2) 如选择了远程压力机发压，请确保参数化文件均已上传至压力机对应路径！！！'''
    print(' README '.center(65, '*'))
    print('发压模式说明：\n{0}'.format(show))
    print('*'.center(65, '*'))


# def exec_cmd(command):
#     output = subprocess.Popen(
#         command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, universal_newlines=True)
#     stdout_info, stderr_info = output.communicate()
#     rtc = output.returncode
#     return stdout_info, stderr_info, rtc


def win_local_no_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Windows_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Windows_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_resfile_format = conf["Windows_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")

    cmd = "cmd.exe /c {0}\jmeter -n -t {1} -l {2}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_resfile_abspath)
    print("Windows系统--local_no_report模式下命令行启动JMeter的命令为：\n%s" % cmd)
    os.system(cmd)
    # output = exec_cmd(cmd)
    # if output[1] != '':
    #     print(f"返回码为 : {output[2]}\n报错信息为 : {output[1]}")
    # else:
    #     print(output[0])


def win_remote_assign_no_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Windows_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Windows_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_remote_assign = conf["Windows_controller_config"]["指定远程发压机的IP及端口"]
    jmeter_resfile_format = conf["Windows_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")

    cmd = "{0}\jmeter -n -t {1} -R {2} -l {3}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_remote_assign, jmeter_resfile_abspath)
    print("Windows系统--remote_assign_no_report模式下命令行启动JMeter的命令为：\n%s" % cmd)
    os.system(cmd)


def win_remote_all_no_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Windows_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Windows_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_resfile_format = conf["Windows_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")

    cmd = "{0}\jmeter -n -t {1} -r -l {2}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_resfile_abspath)
    print("Windows系统--remote_all_no_report模式下命令行启动JMeter的命令为：\n%s" % cmd)
    os.system(cmd)


def win_local_get_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Windows_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Windows_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_resfile_format = conf["Windows_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")
    jmeter_report_abspath = conf["Windows_controller_config"]["JMeter生成测试报告的绝对路径目录"] + r"\report_" + timestamp

    cmd = "{0}\jmeter -n -t {1} -l {2} -e -o {3}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_resfile_abspath, jmeter_report_abspath)
    print("Windows系统--local_get_report模式下命令行启动JMeter的命令为：\n%s" % cmd)
    os.system(cmd)


def win_remote_assign_get_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Windows_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Windows_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_remote_assign = conf["Windows_controller_config"]["指定远程发压机的IP及端口"]
    jmeter_resfile_format = conf["Windows_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")
    jmeter_report_abspath = conf["Windows_controller_config"]["JMeter生成测试报告的绝对路径目录"] + r"\report_" + timestamp

    cmd = "{0}\jmeter -n -t {1} -R {2} -l {3} -e -o {4}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_remote_assign, jmeter_resfile_abspath, jmeter_report_abspath)
    print("Windows系统--remote_assign_get_report模式下命令行启动JMeter的命令为：\n%s" % cmd)
    os.system(cmd)


def win_remote_all_get_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Windows_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Windows_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_resfile_format = conf["Windows_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Windows_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")
    jmeter_report_abspath = conf["Windows_controller_config"]["JMeter生成测试报告的绝对路径目录"] + r"\report_" + timestamp

    cmd = "{0}\jmeter -n -t {1} -r -l {2} -e -o {3}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_resfile_abspath, jmeter_report_abspath)
    print("Windows系统--remote_all_no_report模式下命令行启动JMeter的命令为：\n%s" % cmd)
    os.system(cmd)


def linux_local_no_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Linux_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Linux_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_resfile_format = conf["Linux_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")

    cmd = "{0}\jmeter -n -t {1} -l {2}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_resfile_abspath)
    print("Linux系统--local_no_report模式下命令行启动JMeter的命令为：\n%s" % cmd)


def linux_remote_assign_no_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Linux_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Linux_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_remote_assign = conf["Linux_controller_config"]["指定远程发压机的IP及端口"]
    jmeter_resfile_format = conf["Linux_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")

    cmd = "{0}\jmeter -n -t {1} -R {2} -l {3}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_remote_assign, jmeter_resfile_abspath)
    print("Linux系统--remote_assign_no_report模式下命令行启动JMeter的命令为：\n%s" % cmd)


def linux_remote_all_no_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Linux_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Linux_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_resfile_format = conf["Linux_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")

    cmd = "{0}\jmeter -n -t {1} -r -l {2}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_resfile_abspath)
    print("Linux系统--remote_all_no_report模式下命令行启动JMeter的命令为：\n%s" % cmd)


def linux_local_get_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Linux_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Linux_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_resfile_format = conf["Linux_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")
    jmeter_report_abspath = conf["Linux_controller_config"]["JMeter生成测试报告的绝对路径目录"] + r"\report_" + timestamp

    cmd = "{0}\jmeter -n -t {1} -l {2} -e -o {3}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_resfile_abspath, jmeter_report_abspath)
    print("Linux系统--local_get_report模式下命令行启动JMeter的命令为：\n%s" % cmd)


def linux_remote_assign_get_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Linux_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Linux_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_remote_assign = conf["Linux_controller_config"]["指定远程发压机的IP及端口"]
    jmeter_resfile_format = conf["Linux_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")
    jmeter_report_abspath = conf["Linux_controller_config"]["JMeter生成测试报告的绝对路径目录"] + r"\report_" + timestamp

    cmd = "{0}\jmeter -n -t {1} -R {2} -l {3} -e -o {4}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_remote_assign, jmeter_resfile_abspath, jmeter_report_abspath)
    print("Linux系统--remote_assign_get_report模式下命令行启动JMeter的命令为：\n%s" % cmd)


def linux_remote_all_get_report(choose):
    timestamp = time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))
    jmeter_bin_abspath = conf["Linux_controller_config"]["JMeter的bin目录绝对路径"]
    jmeter_jmx_abspath = conf["Linux_controller_config"]["JMeter测试脚本的绝对路径"]
    jmeter_resfile_format = conf["Linux_controller_config"]["输出的JMeter结果文件格式"]
    if jmeter_resfile_format == 'jtl':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.jtl'
    elif jmeter_resfile_format == 'csv':
        jmeter_resfile_abspath = conf["Linux_controller_config"][
                                     "JMeter测试结果文件夹的绝对路径"] + r"\report_" + timestamp + '.csv'
    else:
        raise ResException(
            f"配置的输出的JMeter结果文件格式是：【{jmeter_resfile_format}】，该配置项仅可填写【csv/jtl】，请修改！")
    jmeter_report_abspath = conf["Linux_controller_config"]["JMeter生成测试报告的绝对路径目录"] + r"\report_" + timestamp

    cmd = "{0}\jmeter -n -t {1} -r -l {2} -e -o {3}".format(
        jmeter_bin_abspath, jmeter_jmx_abspath, jmeter_resfile_abspath, jmeter_report_abspath)
    print("Linux系统--remote_all_no_report模式下命令行启动JMeter的命令为：\n%s" % cmd)


def error_input(choose):
    raise ResException(f"发压方式序号输入的是：【{choose}】，请检查，非可选序号！！！")


def sftp(hostname, port=22, username='root', passwd=''):
    global tran
    try:
        tran = paramiko.Transport(hostname, int(port))  # 获取Transport实例
        tran.connect(username=username, password=passwd)  # 连接SSH服务端
    except SSHException as e:
        print("{0}连接失败！\n报错信息 : \n{1}".format(hostname, e))
    else:
        sftp = paramiko.SFTPClient.from_transport(tran)  # 获取SFTP实例
        local_abspath_file = conf["SFTP"]["需要上传的本地文件路径"]
        remote_abspath_file = conf["SFTP"]["上传对象保存的文件路径"]
        sftp.put(local_abspath_file, remote_abspath_file)  # 执行上传动作
        if local_abspath_file == '':
            raise ResException("请在配置文件中填写需要上传的本地文件路径！")
        elif remote_abspath_file == '':
            raise ResException("请在配置文件中填写上传对象保存的文件路径！")
        else:
            print(f"从本地{local_abspath_file}上传到{hostname}主机的{remote_abspath_file}文件成功！")
        return True
    finally:
        tran.close()


if __name__ == '__main__':
    try:
        default_path = os.path.dirname(os.path.realpath(__file__))
        config_path = os.path.join(default_path, "config.ini")
        conf = configparser.ConfigParser()
        conf.read(config_path, encoding='utf-8')

        # windows控制机
        if conf["Windows_controller_config"]["Windows"] == '1' \
                and conf["Linux_controller_config"]["Linux"] != '1' \
                and conf["SFTP"]["SFTP_only"] != '1':
            show_mode()
            sets = {
                '1': win_local_no_report,
                '2': win_remote_assign_no_report,
                '3': win_remote_all_no_report,
                '4': win_local_get_report,
                '5': win_remote_assign_get_report,
                '6': win_remote_all_get_report,
                '7': error_input,
            }
            choose = str(input("请选择发压方式序号 (1~6) : "))
            sets.get(choose, error_input)(choose)  # get(value,not result return value)

        # linux控制机-仅远程执行，不上传脚本文件
        if conf["Linux_controller_config"]["Linux"] == '1' \
                and conf["Windows_controller_config"]["Windows"] != '1' \
                and conf["SFTP"]["SFTP_only"] != '1':
            show_mode()
            sets = {
                '1': linux_local_no_report,
                '2': linux_remote_assign_no_report,
                '3': linux_remote_all_no_report,
                '4': linux_local_get_report,
                '5': linux_remote_assign_get_report,
                '6': linux_remote_all_get_report,
                '7': error_input,
            }
            choose = str(input("请选择发压方式序号 (1~6) : "))
            sets.get(choose, error_input)(choose)  # get(value,not result return value)

        # 仅SFTP操作
        if conf["SFTP"]["SFTP_only"] == '1' \
                and conf["Windows_controller_config"]["Windows"] != '1' \
                and conf["Linux_controller_config"]["Linux"] != '1':
            zipfile_abspath = conf["SFTP"]["上传对象保存的文件路径"]
            with open('sftp_info.csv') as f:
                lines = csv.reader(f)
                for line in lines:
                    hostname, port, username, passwd = line[0], line[1], line[2], line[3]
                    sftp_info = sftp(hostname, port, username, passwd)

        # SFTP配置项错误情况
        if (conf["SFTP"]["SFTP_only"] == '1'
            and conf["Windows_controller_config"]["Windows"] == '1'
            and conf["Linux_controller_config"]["Linux"] == '1') \
                or (conf["SFTP"]["SFTP_only"] == '1'
                    and conf["Windows_controller_config"]["Windows"] != '1'
                    and conf["Linux_controller_config"]["Linux"] == '1') \
                or (conf["SFTP"]["SFTP_only"] == '1'
                    and conf["Windows_controller_config"]["Windows"] == '1'
                    and conf["Linux_controller_config"]["Linux"] != '1'):
            raise ResException(
                "配置文件中选择仅SFTP上传配置后（即sftp_only = 1），Windows控制机与Linux控制机的配置项均不可为1，请修改配置文件！")

        # 控制机配置项错误情况
        if conf["Windows_controller_config"]["Windows"] == '1' \
                and conf["Linux_controller_config"]["Linux"] == '1' \
                and conf["SFTP"]["SFTP_only"] != '1':
            raise ResException(
                "配置文件中的Windows控制机与Linux控制机仅可选择一项（即仅可一项为1，另一项为空或0），请修改配置文件！")

    except Exception as ex:
        print("报错信息：\n{0}".format(ex))
    finally:
        os.system("pause")
